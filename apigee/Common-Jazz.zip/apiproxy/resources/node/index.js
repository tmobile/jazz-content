var AWS = require('aws-sdk');
var apigee = require('apigee-access');
var http = require('http');
var express = require('express');
//var bodyParser = require('body-parser');
var app = express();

const querystring = require('querystring');
//var lambda = null;

console.log('node.js application starting...');

var server = http.createServer(function (req, res) {

    var accessKeyId = apigee.getVariable(req, 'private.accessKeyId');
    var secretAccessKey = apigee.getVariable(req, 'private.secretAccessKey');
    var region = apigee.getVariable(req, 'private.region');
    var lambdaARN = apigee.getVariable(req, 'private.lambdaARN');

    AWS.config.update({accessKeyId: accessKeyId, secretAccessKey: secretAccessKey});
    AWS.config.region = region;
    
        lambda = new AWS.Lambda();

    // Extract the verb  
    var verb = apigee.getVariable(req, 'request.verb');
    // Extract the path
    var pathsuffix = apigee.getVariable(req, 'proxy.pathsuffix');
        pathsuffix = pathsuffix.replace(/\//g, "");
    // Extract the query params
    var qstring = apigee.getVariable(req, 'request.querystring');
        qstring = querystring.parse(qstring);
        console.log (qstring);
    // Extract the URI
    var uri = apigee.getVariable(req, 'request.uri');
    // Extract the path params 
    var pathparameters = apigee.getVariable(req, 'request.path');
    // Extract the proxy name 
    var proxyname = apigee.getVariable(req, 'apiproxy.name');
    //=========
    // Extract all the Headers
    var headerFieldsCollection = apigee.getVariable(req, 'request.headers.names') + '';

    //Remove square brackets
    headerFieldsCollection = headerFieldsCollection.substr(1, headerFieldsCollection.length - 2);

    //Split string into an array
    var headersArray = headerFieldsCollection.split(", ");
    var RequestHeaders = '{';
    // Loop through Array and get value of header
    for (var i = 0; i < headersArray.length; i++) {
	apigee.setVariable(req,'headers.' + headersArray[i].toLowerCase(), apigee.getVariable(req, 'request.header.' + headersArray[i]));
	
	if(headersArray[i].toLowerCase()!=='authorization'){
		if (i!==0)
			RequestHeaders = RequestHeaders+',';
	    RequestHeaders = RequestHeaders+'"' +headersArray[i]+'":"'+apigee.getVariable(req, 'request.header.' + headersArray[i])+'"';
	    }
    }
    RequestHeaders = RequestHeaders+"}";
    RequestHeaders = JSON.parse(RequestHeaders);
    console.log (RequestHeaders);

    // Extract the payload 
    var payload = apigee.getVariable(req, 'request.content') || '{}';
        payload = JSON.parse(payload);
        console.log (payload);
        //payload = JSON.stringify(payload);
    
    // Extract Path Params
    var pParameters = {};
    pParameters[proxyname] = pathparameters;
    
    // Extract the Lambda Function Name
    var functionName = apigee.getVariable(req, 'request.header.LambdaFunctionName');
    //var functionName = "LambdaFunctionOverHttps";
    console.log(functionName);
    
    sendRequest = {
        functionName: functionName,
        operation: pathsuffix,
        query: qstring,
        queryStringParameters: qstring,
        pathParameters: pParameters,
        httpMethod: verb,
        method: verb,
        headers: RequestHeaders,
        body: payload,
        region: region
    };
    sendRequest = JSON.stringify(sendRequest);
    
    // var sendRequest = apigee.getVariable(request, 'request.content');
    //     sendRequest = JSON.parse(sendRequest);
    //     console.log (sendRequest);
    //     sendRequest = JSON.stringify(sendRequest);
        
        var params = {
                FunctionName: lambdaARN,
                InvocationType: 'RequestResponse',
                LogType: 'Tail',
                Payload: sendRequest 
            };
            console.log("REQ: " + sendRequest);
            
            var responseObj;
            
            lambda.invoke(params, function (err, data) {
                if (err) {
                    console.log("lambda invocation ERROR : " + err);
                    res.end('Error: ' + err);
                } else {
                    //resp.end(data.Payload);
                    responseObj = JSON.parse(data.Payload);
                    
                    if (!responseObj.errorMessage) {
                        
                        res.end(JSON.stringify(responseObj));
                        
                    } 
                    else { 
                        var errorMessage = JSON.parse(responseObj.errorMessage);
                        res.statusCode = errorMessage.errorCode;
                        
                        var responseBody = errorMessage;
                        res.write(JSON.stringify(responseBody));
                        res.end();
                    // resp.errorCode(errorMessage.errorCode).end(errorMessage.message);
                    }
                }
            });
});
server.listen(9000, function() {
    console.log('Node HTTP server is listening');
});